Hi 👋, I'm JACINTH PEARLIN J

🔭 I’m a recent B.Tech graduate in Artificial Intelligence and Data Science
👨‍💻 My portfolio website 

📫 How to reach me pearlin1210@gmail.com
